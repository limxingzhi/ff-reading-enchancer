A browser plugin that enhances your reading speed by bolding the first few characters of every word.

Built for firefox.
